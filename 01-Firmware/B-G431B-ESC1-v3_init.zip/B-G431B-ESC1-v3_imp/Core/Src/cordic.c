/*
 * cordic.c
 *
 *  Created on: 14 janv. 2022
 *      Author: Patrick
 */



