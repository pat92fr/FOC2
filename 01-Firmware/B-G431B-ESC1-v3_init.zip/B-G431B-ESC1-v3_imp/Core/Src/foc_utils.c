/*
 * foc_utils.c
 *
 *  Created on: 13 janv. 2022
 *      Author: Patrick
 */


