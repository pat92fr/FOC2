/*
 * foc.cpp
 *
 *  Created on: 16 janv. 2022
 *      Author: Patrick
 */


#include "foc.hpp"

foc::foc()
{

}
